import java.util.Hashtable;

//TODO change all outside function calls from Amino3 class to Amino class
public class Amino3 {
    //list of the amino - codon relationships. I.E. A (Alanine) = GCA, GCC, GCG, GCT
    static String[] A = {"GCA", "GCC", "GCG", "GCT"};
    static String[] C = {"TGC", "TGT"};
    static String[] D = {"GAC", "GAT"};
    static String[] E = {"GAA", "GAG"};
    static String[] F = {"TTC", "TTT"};
    static String[] G = {"GGA", "GGC", "GGG", "GGT"};
    static String[] H = {"CAC", "CAT"};
    static String[] I = {"ATA", "ATC", "ATT"};
    static String[] K = {"AAA", "AAG"};
    static String[] L = {"CTA", "CTC", "CTG", "CTT", "TTA", "TTG"};
    static String[] M = {"ATG"};
    static String[] N = {"AAC", "AAT"};
    static String[] P = {"CCA", "CCC", "CCG", "CCT"};
    static String[] Q = {"CAA", "CAG"};
    static String[] R = {"AGA", "AGG", "CGA", "CGC", "CGG", "CGT"};
    static String[] S = {"AGC", "AGT", "TCA", "TCC", "TCG", "TCT"};
    static String[] T = {"ACA", "ACC", "ACG", "ACT"};
    static String[] V = {"GTA", "GTC", "GTG", "GTT"};
    static String[] W = {"TGG"};
    static String[] Y = {"TAC", "TAT"};

    public static final Integer NUM_AMINOS = 20;
    public static final String aminoList = "ARNDCQEGHILKMFPSTWYV";
                                           
    public static final Hashtable<String, String[]> AA2CODON = initializeAA2Codon();
    private static Hashtable<String, String[]>  initializeAA2Codon() {
        Hashtable<String, String[]> AA2codon = new Hashtable<String, String[]>();
        AA2codon.put("A",A); AA2codon.put("C",C); AA2codon.put("D",D); AA2codon.put("E",E);
        AA2codon.put("F",F); AA2codon.put("G",G); AA2codon.put("H",H); AA2codon.put("I",I);
        AA2codon.put("K",K); AA2codon.put("L",L); AA2codon.put("M",M); AA2codon.put("N",N);
        AA2codon.put("P",P); AA2codon.put("Q",Q); AA2codon.put("R",R); AA2codon.put("S",S);
        AA2codon.put("T",T); AA2codon.put("V",V); AA2codon.put("W",W); AA2codon.put("Y",Y);
        return AA2codon;
    }

    public static final String[] CODONS = {
            "TTT", "TTC", "TTA", "TTG", "TCT",
            "TCC", "TCA", "TCG", "TAT", "TAC", "TGT", "TGC", "TGG", "CTT",
            "CTC", "CTA", "CTG", "CCT", "CCC", "CCA", "CCG", "CAT", "CAC",
            "CAA", "CAG", "CGT", "CGC", "CGA", "CGG", "ATT", "ATC", "ATA",
            "ATG", "ACT", "ACC", "ACA", "ACG", "AAT", "AAC", "AAA", "AAG",
            "AGT", "AGC", "AGA", "AGG", "GTT", "GTC", "GTA", "GTG", "GCT",
            "GCC", "GCA", "GCG", "GAT", "GAC", "GAA", "GAG", "GGT", "GGC",
            "GGA", "GGG",
    };

    private static final String[] AMINOS_PER_CODON = {
            "F", "F", "L", "L", "S", "S",
            "S", "S", "Y", "Y", "C", "C", "W", "L", "L", "L", "L", "P", "P",
            "P", "P", "H", "H", "Q", "Q", "R", "R", "R", "R", "I", "I", "I",
            "M", "T", "T", "T", "T", "N", "N", "K", "K", "S", "S", "R", "R",
            "V", "V", "V", "V", "A", "A", "A", "A", "D", "D", "E", "E", "G",
            "G", "G", "G",
    };

    public static final Hashtable<String, String> CODON2AA = initializeCodon2AA();
   
   
    private static Hashtable<String, String>  initializeCodon2AA() {
        Hashtable<String, String> codon2AA = new Hashtable<String, String>();
        for(int i = 0; i < AMINOS_PER_CODON.length; i++) {
            codon2AA.put(CODONS[i],AMINOS_PER_CODON[i]);
        }
        return codon2AA;
    }
}
