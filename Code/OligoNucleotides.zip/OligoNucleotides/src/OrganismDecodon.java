public class OrganismDecodon {
    private String[] decodonList;
    private Float correctnessFactor;
    private Integer location;
    
    public OrganismDecodon(String[] decodonList, Float correctnessFactor) {
        this.decodonList = decodonList;
        this.correctnessFactor = correctnessFactor;
        this.location = null;
    }
    
    public String[] getDecodonList() {return decodonList;}
    public Float getCorrectnessFactor() {return correctnessFactor;}
}
