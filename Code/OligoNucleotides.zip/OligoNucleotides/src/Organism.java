import java.io.File;
import java.io.FileNotFoundException;
import java.util.Hashtable;
import java.util.Scanner;



/*the organism class stores organism specific information
Specifically, the codon ratios of the organism and the decodon set information*/

public class Organism {
    
    //stores the number of times each codon appears on average in a given organism's genome
    private static final Hashtable<String, Integer> codonAmounts = new Hashtable<>(82);
    private static final Hashtable<String, OrganismDecodon> organismDecodonHash = new Hashtable<>(1394605);
    private static String name;
    Organism(String codonDistributionFileName, String decodonFileName, String name) {
        
        //Setting the name
        this.name = name;
        //populating codonAmounts
        File codonFile = new File(codonDistributionFileName);
        try (Scanner fileScanner = new Scanner(codonFile)) {

            while(fileScanner.hasNext()) {
                fileScanner.next();
                String codon = fileScanner.next();
                String amount = fileScanner.next();
                fileScanner.next();
                fileScanner.next();
                codonAmounts.put(codon, Math.round(Float.valueOf(amount)));
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        //populating decodonSet
        File decodonFile = new File(decodonFileName);
        try (Scanner fileScanner = new Scanner(decodonFile)) {
            
            int currentLine = 0;
            while(fileScanner.hasNext()) {
                
                Integer numCodons = Integer.valueOf(fileScanner.next());
                String aminoList = fileScanner.next();
                String[] decodonList = new String[numCodons];
                for (int i = 0; i < numCodons; i++) {
                    decodonList[i] = fileScanner.next();
                }
                Float correctnessFactor = Float.valueOf(fileScanner.next());
                
                OrganismDecodon currDecodon = new OrganismDecodon(decodonList, correctnessFactor);
                organismDecodonHash.put(aminoList, currDecodon);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
         
    }
    //takes a codon as input and returns the corresponding codon Amount
    public Integer codonAmount(String codon) {return codonAmounts.get(codon);}
    
    public OrganismDecodon getDecodons (String aminoSequence) {return organismDecodonHash.get(aminoSequence);}

    public String getName() {return name;}
}

