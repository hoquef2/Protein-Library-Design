
public class MeltingTemp {
    // takes in a DNA sequence string as input and outputs its melting temperature as a float
    public static double calcTemp(String seq) {
        int wA = 0; // number of A's in sequence
        int xT = 0; // number of T's in sequence
        int yG = 0; // number of G's in sequence
        int zC = 0; // number of C's in sequence
        double Na = 0.05; // sodium concentration (can be changed)
        

        char c; // will hold each char in sequence
        double temp = 0; // holds calculated temp

        seq = seq.replaceAll("\\s", ""); // gets rid of spaces in sequence

        // loops through each letter in sequence
        for(int i = 0; i < seq.length(); i++) {
            c = seq.charAt(i);

            if(c == 'A') {
                wA++;
            } else if(c == 'T') {
                xT++;
            } else if(c == 'G') {
                yG++;
            } else if(c == 'C') {
                zC++;
            } else {
                continue;
            }
        }

        // equation is different if sequence length is greater than 13
        if(seq.length() <= 13 ) {
            temp = (wA + xT)*2 + (yG + zC) *4 -(16.6 * Math.log10(.050)) + (16.6* Math.log10(Na));
        } else {
            temp = 100.5 + (41 * (yG+zC)/(wA+xT+yG+zC)) - (820/(wA+xT+yG+zC)) + (16.6*Math.log10(Na));
        }

        System.out.print("Melting temp: ");
        // limits the number of decimal places
        System.out.format("%.1f", temp);
        System.out.println();
        return temp;
    }
}
// reference website:
// http://biotools.nubic.northwestern.edu/OligoCalc.html

