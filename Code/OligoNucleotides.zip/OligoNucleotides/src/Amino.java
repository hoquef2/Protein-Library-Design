import java.util.HashMap;

public class Amino {
    
    //name of amino acid. Eg: Serine
    private final String name;
    
    //Eg: Serine -> Ser
    private final String threeLetterAbbreviation;
    
    //Eg: Serine -> S
    private final Character oneLetterAbbreviation;
    
    //Eg: Serine -> {"AGC", "AGT", "TCA", "TCC", "TCG", "TCT"}
    private final String[] codons;
    
    //the codon with the minimum number of C/G's, which codes for the amino
    //stored as a three bit binary string. with C/G == 1 and A/T == 0 
    //Eg: Serine -> "010"
    private final String minCGcodonBinary;
    //the codon with the minimum number of C/G's, which codes for the amino
    //stored as a three bit binary string. with C/G == 1 and A/T == 0 
    //Eg: Serine -> "011"
    private final String maxCGcodonBinary;
    
    private Amino(String name, String threeLetterAbbreviation, Character oneLetterAbbreviation
            , String[] codons, String minCGcodonBinary, String maxCGcodonBinary) {
        this.name = name;
        this.threeLetterAbbreviation = threeLetterAbbreviation;
        this.oneLetterAbbreviation = oneLetterAbbreviation;
        this.codons = codons;
        this.minCGcodonBinary = minCGcodonBinary;
        this.maxCGcodonBinary = maxCGcodonBinary;
    }

    public String getName() {return name;}
    public Character getOneLetterAbbreviation() {return oneLetterAbbreviation;}
    public String getThreeLetterAbbreviation() {return threeLetterAbbreviation;}
    public String[] getCodons() {return codons;}
    public String getMinCGcodonBinary() {return minCGcodonBinary;}
    public String getMaxCGcodonBinary() {return maxCGcodonBinary;}
    public static final Integer NUM_AMINOS = 20;
    public static final String aminoList = "ARNDCQEGHILKMFPSTWYV";

    static final Amino A = new Amino("Alanine","Ala",'A',
            new String[]{"GCA", "GCC", "GCG", "GCT"},"110","111");
    static final Amino C = new Amino("Cystein","Cys",'C',
            new String[]{"TGC", "TGT"},"010","011");
    static final Amino D = new Amino("Aspartic Acid","Asp",'D',
            new String[]{"GAC", "GAT"},"100","101");
    static final Amino E = new Amino("Glutamic Acid","Glu",'E',
            new String[]{"GAA", "GAG"},"100","101");
    static final Amino F = new Amino("Phenilalanine","Phe",'F',
            new String[]{"TTC", "TTT"},"000","001");
    
    static final Amino G = new Amino("Glycine","Gly",'G',
            new String[]{"GGA", "GGC", "GGG", "GGT"},"110","111");
    static final Amino H = new Amino("Histidine","His",'H',
            new String[]{"CAC", "CAT"},"100","101");
    static final Amino I = new Amino("Isoleucine","Ile",'I',
            new String[]{"ATA", "ATC", "ATT"},"000","001");
    static final Amino K = new Amino("Lysine","Lys",'K',
            new String[]{"AAA", "AAG"},"000","001");
    static final Amino L = new Amino("Leucine","Leu",'L',
            new String[]{"CTA", "CTC", "CTG", "CTT", "TTA", "TTG"},"000","101");
    
    static final Amino M = new Amino("Metionine","Met",'M',
            new String[]{"ATG"},"001","001");
    static final Amino N = new Amino("Asparagine","Asn",'N',
            new String[]{"AAC", "AAT"},"000","001");
    static final Amino P = new Amino("Proline","Pro",'P',
            new String[]{"CCA", "CCC", "CCG", "CCT"},"110","111");
    static final Amino Q = new Amino("Glutamine","Gln",'Q',
            new String[]{"CAA", "CAG"},"100","101");
    static final Amino R = new Amino("Arginine","Arg",'R',
            new String[]{"AGA", "AGG", "CGA", "CGC", "CGG", "CGT"},"010","111");
    
    static final Amino S = new Amino("Serine","Ser",'S',
            new String[]{"AGC", "AGT", "TCA", "TCC", "TCG", "TCT"},"010","011");
    static final Amino T = new Amino("Threonine","Thr",'T',
            new String[]{"ACA", "ACC", "ACG", "ACT"},"010","011");
    static final Amino V = new Amino("Valine","Val",'V',
            new String[]{"GTA", "GTC", "GTG", "GTT"},"100","101");
    static final Amino W = new Amino("Tryptophan","Trp",'W',
            new String[]{"TGG"},"011","011");
    static final Amino Y = new Amino("Tyrosine","Tyr",'Y',
            new String[]{"TAC", "TAT"},"000","001");

    //HashMap with a key of an amino acid in single letter form and a value of said amino acid
    public static HashMap<Character, Amino> aminoByLetter = initAminoByLetter();
    private static HashMap<Character, Amino> initAminoByLetter() {
        HashMap<Character, Amino> aminoByLetter = new HashMap<>();
        aminoByLetter.put('A',A); aminoByLetter.put('C',C); aminoByLetter.put('D',D); aminoByLetter.put('E',E);
        aminoByLetter.put('F',F); aminoByLetter.put('G',G); aminoByLetter.put('H',H); aminoByLetter.put('I',I);
        aminoByLetter.put('K',K); aminoByLetter.put('L',L); aminoByLetter.put('M',M); aminoByLetter.put('N',N);
        aminoByLetter.put('P',P); aminoByLetter.put('Q',Q); aminoByLetter.put('R',R); aminoByLetter.put('S',S);
        aminoByLetter.put('T',T); aminoByLetter.put('V',V); aminoByLetter.put('W',W); aminoByLetter.put('Y',Y);
        return aminoByLetter;
    }
}
