public class DNAdecodon {
    private String[] decodonList;
    private Integer location;
    
    public DNAdecodon(String[] decodonList, Integer location) {
        this.decodonList = decodonList;
        this.location = location;
    }

    public String[] getDecodonList() {return decodonList;}

    public Integer getLocation() {return location;}
}
