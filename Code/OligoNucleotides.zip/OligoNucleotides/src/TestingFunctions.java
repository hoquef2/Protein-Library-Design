import java.util.Formatter;

public class TestingFunctions {
    public static void printCGamountTemperature(Integer minTemp, Integer maxTemp, Integer[][] CGamountTemperature) {
        System.out.print("Curr Temp (C):   ");
        for(int currTempIndex = minTemp; currTempIndex < maxTemp; currTempIndex++){
            Formatter formatter = new Formatter();
            formatter.format("%-6.0f", (float) currTempIndex);
            System.out.print(formatter + " ");
        }

        System.out.print("\n_________________");
        for(int currTempIndex = minTemp; currTempIndex < maxTemp; currTempIndex++){
            System.out.print("_______");
        }
        System.out.println();
        
        for(int currCG_PercentageIndex = 0; currCG_PercentageIndex < 21; currCG_PercentageIndex ++) {
            float currCGpercentage = ((float) currCG_PercentageIndex * 5);
            Formatter formatter = new Formatter();
            formatter.format("%3.0f", currCGpercentage);
            System.out.print(formatter + "% CG content: ");

            for (int currTempIndex = 0; currTempIndex < maxTemp - minTemp; currTempIndex++) {
                Formatter formatter1 = new Formatter();
                Integer currLen = CGamountTemperature[currCG_PercentageIndex][currTempIndex];
                if (currLen == null) {
                    System.out.print("null   ");
                } else {
                    formatter1.format("%-6.0f", (float) currLen);
                    System.out.print(formatter1 + " ");
                }
            }
            System.out.println();
        }
    }
}
