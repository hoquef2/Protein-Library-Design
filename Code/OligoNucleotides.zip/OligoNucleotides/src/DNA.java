import java.util.ArrayList;

public class DNA {
    private String[] DNAsequence;
    private DNAdecodon[] decodonSet;
    private Organism organism;

    public DNA(Protein protein, Organism organism) {
        String proteinSequence = protein.getSequence();
        ArrayList<AlternateAminos> aminoList = protein.getAlternateAminos();
        String OrganismName = organism.getName();

        String[] DNAsequence = new String[proteinSequence.length()];

        //converting protein sequence into DNA sequence
        //for each amino acid
        for (int i = 0; i < Amino3.aminoList.length(); i++) {
            //number of aminoAcid occurrences
            Integer aminoAmount = 0;
            //location of each Amino Acid occurrence
            ArrayList<Integer> aminoLocations = new ArrayList<Integer>();
            //computing aminoAmount and aminoLocations
            for (int j = 0; j < proteinSequence.length(); j++) {
                if (proteinSequence.charAt(j) == Amino3.aminoList.charAt(i)) {
                    aminoAmount++;
                    aminoLocations.add(j);
                }
            }


            String currentAmino = String.valueOf(Amino3.aminoList.charAt(i));
            //generate an int array with size = the frequency of the given amino acid in the protein sequence
            Integer[] codonRandomizer = randomPermutation(aminoAmount);
            //String array containing the corresponding codons
            String[] codons = Amino3.AA2CODON.get(currentAmino);
            Integer[] codonAmounts = new Integer[codons.length];

            //populating codonAmounts
            for (int currCodonIndex = 0; currCodonIndex < codons.length; currCodonIndex++) {
                String currCodon = codons[currCodonIndex];
                codonAmounts[currCodonIndex] =
                        OrganismList.getOrganism(OrganismName).codonAmount(currCodon);
            }
            Integer[] allocationList = apportionment(codonAmounts, aminoAmount);

            //for every codon
            for (int codonElement = 0; codonElement < codons.length; codonElement++) {
                //for every aminoacid location

                for (int permutationElement = 0; permutationElement < aminoAmount; permutationElement++) {
                    // permutationList[element] <= allocationList[codonNumber]
                    if (codonRandomizer[permutationElement] <= allocationList[codonElement]) {
                        //DNAsequence[aminoLocations[permutationElement]] = currentCodon
                        DNAsequence[aminoLocations.get(permutationElement)] = codons[codonElement];
                        //break
                    }
                }
            }
        }
        
        DNAdecodon[] decodonSet = new DNAdecodon[aminoList.size()];
        for (int alternateAmino = 0; alternateAmino < aminoList.size(); alternateAmino++) {
            String aminoSequence = aminoList.get(alternateAmino).toBinary();
            Integer location = aminoList.get(alternateAmino).getLocation();
            String[] decodonList = organism.getDecodons(aminoSequence).getDecodonList();
            DNAdecodon dnaDecodon = new DNAdecodon(decodonList, location);
            decodonSet[alternateAmino] = dnaDecodon;
        }

        this.DNAsequence = DNAsequence;
        this.decodonSet = decodonSet;
        this.organism = organism;
    }

    //helper function: generates a random permutation from 1 through N
    private static Integer[] randomPermutation(int size) {
        Integer[] array = new Integer[size];

        for (int i = 0; i < size; i++) {
            array[i] = i;
        }

        for (int i = size - 1; i >= 0; i--) {
            int indexToBeSwapped = (int) (Math.random() * i);

            int temp = array[indexToBeSwapped];
            array[indexToBeSwapped] = array[i];
            array[i] = temp;

        }
        return array;
    }

    //Helper: uses the Huntington - Hill method of apportionment to most fairly distribute amino acids among codons
    private Integer[] apportionment(Integer[] codonAmounts, Integer numberOfAminos) {
        Integer numberOfCodons = codonAmounts.length;
        
        double[] quota = new double[numberOfCodons];
        Integer[] lowerQuota = new Integer[numberOfCodons];
        Float[] geoMeanLowerQuota = new Float[numberOfCodons];
        Integer[] allocationList = new Integer[numberOfCodons];
        Integer totalCodonAmount = 0;
        Integer allocation = 0;

        //computing the standard divisor
        for (Integer codonAmount : codonAmounts) {
            totalCodonAmount += codonAmount;
        }
        Double divisorHigh = totalCodonAmount.doubleValue() / numberOfAminos;
        Double divisorLow = divisorHigh;
        Double divisorAvg;

        while (numberOfAminos != allocation) {
            //resetting allocation value
            allocation = 0;

            divisorAvg = (divisorHigh + divisorLow) / 2;
            for (int i = 0; i < numberOfCodons; i++) {
                //computing the quota for codon
                Integer codonAmount = codonAmounts[i];
                quota[i] = codonAmount / divisorAvg;

                //computing the lower quota for codon
                lowerQuota[i] = (int) Math.floor(quota[i]);

                //computing the geometric mean of the lower quota and one value higher for codon
                geoMeanLowerQuota[i] = (float) Math.sqrt(lowerQuota[i] * (lowerQuota[i] + 1));

                //computing the allocation
                if (quota[i] < geoMeanLowerQuota[i]) {
                    allocationList[i] = (int) Math.floor(quota[i]);
                } else {
                    allocationList[i] = (int) Math.ceil(quota[i]);
                }
                allocation += allocationList[i];
            }

            //If the allocation is to small or to large, recompute the divisor anr recalculate allocationList
            if (allocation < numberOfAminos) {
                //Checks if this is the initial run-through
                if (divisorHigh == divisorLow) {
                    divisorLow = divisorHigh * 0.9;
                } else {
                    divisorHigh = divisorAvg;
                }
            } else if (allocation > numberOfAminos) {
                //Checks if this is the initial run-through
                if (divisorHigh == divisorLow) {
                    divisorHigh = divisorLow * 1.2;
                } else {
                    divisorLow = divisorAvg;
                }
            }
        }

        //formats the allocation list for easy use in allocation aminos to codons
        Integer[] adjustedAllocationList = new Integer[numberOfCodons];

        adjustedAllocationList[0] = allocationList[0] - 1;
        Integer total = adjustedAllocationList[0];
        for (int i = 1; i < numberOfCodons; i++) {
            adjustedAllocationList[i] = allocationList[i] + total;
            total += adjustedAllocationList[i];
        }

        return adjustedAllocationList;
    }

    public String[] getDNAsequence() {return DNAsequence;}

    public DNAdecodon[] getDecodonSet() {return decodonSet;}
    public Organism getOrganism() {return organism;}
}