public class Input{
    private Integer minTemp;
    private Integer maxTemp;
    private Integer minLen;
    private Integer maxLen;
    private String fastaFile;
    private String alternateAminoFile;
    private organism anOrganism;
    public enum organism{
        HUMAN, MOUSE, ECOLI
    };
    public Integer getMinTemp() {return minTemp;};
    public Integer getMaxTemp() {return maxTemp;};
    public Integer getMinLen() {return minLen;};
    public Integer getMaxLen() {return maxLen;};
    public String getFastaFile(){return fastaFile;};
    public String getAlternateAminoFile(){return alternateAminoFile;};
    public organism getOrganism(){return anOrganism;};

    //I need help implementing an organism enum as a parameter
    public Input(Integer minTemp, Integer maxTemp, Integer minLen, Integer maxLen,
                 String fastaFile, String alternateAminoFile, organism anOrganism) {
        this.minTemp = minTemp;
        this.maxTemp = maxTemp;
        this.minLen = minLen;
        this.maxLen = maxLen;
        this.fastaFile = fastaFile;
        this.alternateAminoFile = alternateAminoFile;
        this.anOrganism = anOrganism;
    }

}
