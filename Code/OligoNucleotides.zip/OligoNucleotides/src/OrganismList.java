import java.util.ArrayList;
import java.util.Hashtable;

public class OrganismList {
    private static Hashtable<String, Organism> organismHash = new Hashtable<String, Organism>() {};
    
    private static void addOrganism(String name, String organismFile, String decodonFile) {
        Organism organism = new Organism(organismFile, decodonFile, name);
        organismHash.put(name, organism);
    }
    OrganismList() {
        addOrganism("Human", "src/Files/OrganismFile", "C:\\AA_set_decodons.human (1).txt");
    }
    
    public static Organism getOrganism(String organismName) {return organismHash.get(organismName);}
}
