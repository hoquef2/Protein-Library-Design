import java.io.IOException;
import java.util.Formatter;


import static java.lang.System.nanoTime;

public class Main {
    public static void main(String[] args) throws IOException {
        long startTime = nanoTime()/1000000000;
        Input input1 = new Input(48, 100, 15, 100,
                "src/Files/FASTA", "src/Files/AlternateAminos", Input.organism.ECOLI);
        Protein protein1 = new Protein(input1);
        System.out.println("Protein Title: " + protein1.getTitle() +
                "\r\nProtein Sequence: " + protein1.getSequence() +
                "\r\nAlternate Aminos: " + protein1.getAlternateAminos());
        
        String[] string;
        
        
        //displays conversion from Amino Acid to Codon
        /*for (Map.Entry<String, String[]> e : Amino.AA2CODON.entrySet()) {
            String[] string = e.getValue();
            System.out.print(e.getKey() + " : ");
            for(int i = 0; i < string.length; i++) {
                System.out.print(e.getValue()[i]+ " ");
            }
            System.out.println();

        }*/

        //displays conversion from Codon to Amino Acid
        /*for (Map.Entry<String, String> e : Amino.CODON2AA.entrySet()) {
            System.out.print(e.getKey() + " " + e.getValue() + "|");
        }
        System.out.println();
        */
        
        //displays the frequency of each Amino Acid in the protein sequence
        /*for(int i = 0; i < protein1.getAminoFrequencies().length; i++) {
            System.out.print(Amino.aminoList.charAt(i) + ": " + protein1.getAminoFrequencies()[i] + "| ");
        }
        System.out.println();
        */

        //randomPermutation Generator
        /*Integer[] array = randomPermutation.randomPermutation(3476);
        int total = 0;
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + ", ");
            total += array[i];
        }
        System.out.println("\nTotal is: " + total);
        */
        
        //Organism organism1 = new Organism("Human", "src/OrganismFile");

        //prints out absoluteCodonFrequency
        /*
        for (Map.Entry<String, Float> e : organism1.getAbsoluteCodonFrequency().entrySet()) {
            Float string = e.getValue();
            System.out.print(e.getKey() + ": " + string);
            
            System.out.println();

        }*/
        //prints out relativeCodonFrequency
        /*for (Map.Entry<String, Float> e : organism1.getRelativeCodonFrequency().entrySet()) {
            Float relativeCodonFrequency = e.getValue();
            System.out.print(e.getKey() + ": " + relativeCodonFrequency);

            System.out.println();*/
        
        //protein1.test();
        
        //converting Protein to DNA
        /*new OrganismList();
        DNA DNA1 = new DNA(protein1, OrganismList.getOrganism("Human"));
        
        String organismName = DNA1.getOrganism().getName();
        DNAdecodon[] decodonSet = DNA1.getDecodonSet();
        String[] DNAsequence = DNA1.getDNAsequence();
        
        System.out.println("Organism: " + organismName);
        for(DNAdecodon decodons : decodonSet) {
            String[] decodonList = decodons.getDecodonList();
            Integer location = decodons.getLocation();
            System.out.print(location + ": ");
            for(String decodon: decodonList) {
                System.out.print(decodon + ", ");
            }
            System.out.println();
            
        }
        System.out.print("DNAsequence: ");
        for(String codon : DNAsequence) {
            System.out.print(codon + ", ");
        }
        System.out.println();*/

        long endTime = nanoTime()/1000000000;
        
        MeltingTemp.calcTemp("ACTCTGTC");
        
        System.out.println("Duration: " + (endTime - startTime) + " seconds");
        
        String minTempSequence = UsefulFunctions.binaryTempSequence(protein1.getSequence(), "Min");
        String maxTempSequence = UsefulFunctions.binaryTempSequence(protein1.getSequence(), "Max");
        
        
        /*
        for(Integer length= 0; length < input1.getMaxLen(); length++){
            for(Integer CGpercentageIndex = 0; CGpercentageIndex < 21; CGpercentageIndex++){
                Float CGpercentage = (float)CGpercentageIndex / 20;
                Integer temp = UsefulFunctions.tempCalculator(CGpercentage, length, 0.05F);
                System.out.println("CGpercentage: " + CGpercentage + " Length: " + length + " Temperature: " + temp);
            }
        }*/


        //UsefulFunctions.LengthCalculatorStorage(input1.getMinTemp(), input1.getMaxTemp(), 0.05F);

        
        //prints out length determination array
        Integer[][] minLengthArray = UsefulFunctions.LengthCalculator(minTempSequence, input1.getMinTemp(), input1.getMaxTemp(), input1.getMaxLen(), "Min");
        Integer[][] maxLengthArray = UsefulFunctions.LengthCalculator(maxTempSequence, input1.getMinTemp(), input1.getMaxTemp(), input1.getMaxLen(), "Max");


        
        
        for(int currTemp = 0; currTemp < input1.getMaxTemp() - input1.getMinTemp(); currTemp ++) {
            System.out.println("currTemp: " + (currTemp + input1.getMinTemp()));
            System.out.print("Min Length:");
            for(int currLoc = 0; currLoc < minLengthArray.length; currLoc++) {
                Formatter formatter = new Formatter();
                formatter.format("%-3.0f", (float) minLengthArray[currLoc][currTemp]);
                System.out.print(formatter + " ");
            }
            System.out.println();
            System.out.print("Max Length:");
            for(int currLoc = 0; currLoc < maxLengthArray.length; currLoc++) {
                Formatter formatter = new Formatter();
                formatter.format("%-3.0f", (float) maxLengthArray[currLoc][currTemp]);
                System.out.print(formatter + " ");
            }
            System.out.println("\n");
        }

        System.out.println(minTempSequence);
        System.out.println(maxTempSequence);


    }
}


