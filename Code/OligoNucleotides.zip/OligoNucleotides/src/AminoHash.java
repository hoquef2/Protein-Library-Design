import java.util.HashMap;

public class AminoHash {
    

    
}
