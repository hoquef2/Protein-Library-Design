import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import static java.lang.Integer.parseInt;

public class Protein {

    private String title;
    private String proteinSequence;
    private ArrayList<AlternateAminos> alternateAminosList = new ArrayList<AlternateAminos>();


    
    Protein(Input input) {
        //inputting the FASTA file which contains the protein title and the protein sequence
        try (FileReader fafsaFileReader = new FileReader(input.getFastaFile())) {
            StringBuffer rawData = new StringBuffer();
            // Holds true till there is nothing to read
            // converts input text into a String
            int i;
            while ((i = fafsaFileReader.read()) != -1) {
                // Print all the content of a file
                char currentChar = (char) i;
                rawData.append(currentChar);
            }
            //perhaps, I need to test this line of code out to make sure it is doing what I want it to be doing
            int startOfTitle = rawData.indexOf(">");
            int firstLineBreak = Math.min(rawData.indexOf("\r\n"), Math.min(rawData.indexOf("\r"), rawData.indexOf("\n")));
            title = rawData.substring(startOfTitle + 1, firstLineBreak);

            //cleaning up the rawData in for insertion into sequence
            proteinSequence = rawData.substring(firstLineBreak + 1);
            proteinSequence = proteinSequence.replaceAll("\\s", "");

            //this combination of exceptions work, but I do not know why. Could you please explain.
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        //inputting the alternate Aminos File
        try (FileReader alternateAminosFileReader = new FileReader(input.getAlternateAminoFile())) {
            StringBuffer rawData = new StringBuffer();
            // Holds true till there is nothing to read
            // converts input text into a String
            int i;
            while ((i = alternateAminosFileReader.read()) != -1) {
                // Print all the content of a file
                char currentChar = (char) i;
                rawData.append(currentChar);
            }
            String rawDataString = rawData.toString();
            Scanner dataScanner = new Scanner(rawDataString);
            ArrayList<String> data = new ArrayList<String>();
            while (dataScanner.hasNext()) {
                data.add(dataScanner.next());
            }

            //parsing data to pull out position and value information
            //data stores both position and value information, so one must divide by two in order to parse
            for (i = 0; i < data.size() / 2; i++) {
                Integer position = parseInt(data.get(i * 2));
                String values = data.get((i * 2) + 1);
                AlternateAminos currentAlternateAminos = new AlternateAminos(values, position);
                alternateAminosList.add(currentAlternateAminos);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }

    public String getTitle() {
        return title;
    }

    public String getSequence() {
        return proteinSequence;
    }

    public ArrayList<AlternateAminos> getAlternateAminos() {
        return alternateAminosList;
    }
}
